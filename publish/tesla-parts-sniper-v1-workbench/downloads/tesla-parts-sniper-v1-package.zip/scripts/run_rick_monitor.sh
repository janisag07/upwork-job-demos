#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ -d .venv ]; then . .venv/bin/activate; fi
python src/run_monitor.py --config config/rick_v1.json --output output/listings.csv --sheet-dir output/google_sheet_import --max-per-query 2 --max-profiles 8 --max-sites 6
python src/create_google_sheet_xlsx.py --csv-dir output/google_sheet_import --output output/Tesla_Parts_Sniper_V1_Rick_Google_Sheet.xlsx
