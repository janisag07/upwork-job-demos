from urllib.parse import quote_plus


def vehicle_years(vehicle):
    return range(int(vehicle["year_min"]), int(vehicle["year_max"]) + 1)


def build_queries(config):
    """Generate prioritized search queries from Rick's V1 scope."""
    queries = []
    for vehicle in config["vehicles"]:
        for year in vehicle_years(vehicle):
            model = vehicle["model"]
            for part in config["parts"]:
                base = f"Tesla {year} {model} {part}"
                queries.append({"year": year, "model": model, "part": part, "color": "", "query": base})
                for color in config["colors"]:
                    queries.append({"year": year, "model": model, "part": part, "color": color, "query": f"{base} {color}"})
    return queries


def ebay_url(query):
    q = quote_plus(query)
    return f"https://www.ebay.com/sch/i.html?_nkw={q}&_sacat=6028&_rss=1"


def ebay_browser_url(query):
    q = quote_plus(query)
    return f"https://www.ebay.com/sch/i.html?_nkw={q}&_sacat=6028"


def craigslist_rss_url(site, query):
    q = quote_plus(query)
    return f"https://{site}.craigslist.org/search/pta?format=rss&query={q}"


def craigslist_browser_url(site, query):
    q = quote_plus(query)
    return f"https://{site}.craigslist.org/search/pta?query={q}"


def manual_review_links(query):
    q = quote_plus(query)
    fb_q = quote_plus(query.replace(' ', '%20'))
    return {
        "Car-Part.com": f"https://www.car-part.com/cgi-bin/search.cgi?userSearch=int&userPart={q}",
        "Copart": f"https://www.copart.com/lotSearchResults?free=true&query={q}",
        "IAAI": f"https://www.iaai.com/Search?Keyword={q}",
        "Facebook Marketplace": f"https://www.facebook.com/marketplace/search/?query={fb_q}"
    }
