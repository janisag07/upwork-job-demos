import csv
from pathlib import Path

from scoring import duplicate_key, now_iso, score_listing
from search_profiles import craigslist_browser_url, ebay_browser_url, manual_review_links

COLUMNS = [
    "Source", "Listing title", "Price", "Location", "Vehicle year/model", "Part type", "Color",
    "Seller name if available", "Phone/contact if available", "Direct listing link", "Date found",
    "Match score", "Duplicate yes/no", "Status", "Notes"
]

SEARCH_PROFILE_COLUMNS = [
    "Priority", "Vehicle year/model", "Part type", "Color", "Query", "eBay Motors URL",
    "Craigslist priority URLs", "Car-Part URL", "Copart URL", "IAAI URL", "Facebook Marketplace manual URL"
]

PIPELINE_COLUMNS = [
    "Status", "Meaning", "Manual action"
]

SETTINGS_COLUMNS = ["Setting", "Value"]


def _first_non_empty(*values):
    for value in values:
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


PART_ALIASES = {
    "front bumper": ["front bumper", "bumper cover front"],
    "rear bumper": ["rear bumper", "bumper cover rear"],
    "headlight": ["headlight", "headlamp"],
    "hatch": ["hatch", "liftgate"],
    "trunk": ["trunk", "tailgate"],
    "fender": ["fender", "quarter panel"],
    "wheel": ["wheel", "rim", "rims"],
    "seat": ["seat", "seats"],
    "suspension": ["suspension", "control arm", "strut", "knuckle"],
    "module": ["module", "computer", "ecu"],
    "hood": ["hood"],
    "door": ["door"],
}

COLOR_ALIASES = {
    "white": ["white", "pearl"],
    "black": ["black"],
    "red": ["red"],
    "blue": ["blue"],
    "gray": ["gray", "grey", "silver"],
}


def _infer_from_text(text, aliases):
    t = (text or "").lower()
    for canonical, words in aliases.items():
        if any(w in t for w in words):
            return canonical
    return ""


def _infer_vehicle(text, profile):
    explicit = _first_non_empty(profile.get("year_model"), profile.get("vehicle"), profile.get("Vehicle year/model"))
    if explicit:
        return explicit
    title = text or ""
    year = _first_non_empty(profile.get("year"))
    model = _first_non_empty(profile.get("model"))
    if not year:
        m = __import__("re").search(r"\b(20\d{2})\b", title)
        year = m.group(1) if m else ""
    if not model:
        low = title.lower()
        if "model y" in low:
            model = "Model Y"
        elif "model 3" in low:
            model = "Model 3"
    return " ".join(x for x in [year, "Tesla" if (year or model) else "", model] if x).strip()


def to_sheet_row(listing, seen):
    p = listing.get("profile", {}) or {}
    text = " ".join(str(listing.get(k, "")) for k in ["title", "description", "location"])
    score, reasons = score_listing(listing, p)
    is_manual = bool(listing.get("manual_only"))
    part = _first_non_empty(listing.get("part"), listing.get("part_type"), listing.get("Part type"), p.get("part"))
    color = _first_non_empty(listing.get("color"), listing.get("Color"), p.get("color"))
    if part in {"part", "parts"}:
        part = ""
    if not part:
        part = _infer_from_text(text, PART_ALIASES)
    if not color:
        color = _infer_from_text(text, COLOR_ALIASES)
    row = {
        "Source": _first_non_empty(listing.get("Source"), listing.get("source")),
        "Listing title": _first_non_empty(listing.get("Listing title"), listing.get("title")),
        "Price": _first_non_empty(listing.get("Price"), listing.get("price")),
        "Location": _first_non_empty(listing.get("Location"), listing.get("location")),
        "Vehicle year/model": _first_non_empty(listing.get("Vehicle year/model"), _infer_vehicle(text, p)),
        "Part type": part,
        "Color": color,
        "Seller name if available": _first_non_empty(listing.get("Seller name if available"), listing.get("seller"), listing.get("seller_name")),
        "Phone/contact if available": _first_non_empty(listing.get("Phone/contact if available"), listing.get("contact"), listing.get("phone")),
        "Direct listing link": _first_non_empty(listing.get("Direct listing link"), listing.get("link"), listing.get("url")),
        "Date found": _first_non_empty(listing.get("Date found"), listing.get("date_found"), now_iso()),
        "Match score": str(score),
        "Duplicate yes/no": "No",
        "Status": "Manual Review" if is_manual else ("Strong Match" if score >= 80 else "Watchlist"),
        "Notes": _first_non_empty(listing.get("Notes"), listing.get("notes"), reasons + ("; manual review/no automated outreach" if is_manual else "")),
    }
    key = duplicate_key(row)
    if key in seen:
        row["Duplicate yes/no"] = "Yes"
        row["Status"] = "Duplicate"
    seen.add(key)
    return row


def write_csv(path, rows, columns=COLUMNS):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=columns)
        w.writeheader()
        for row in rows:
            w.writerow({c: row.get(c, "") for c in columns})


def build_search_profile_rows(config, profiles, craigslist_sites):
    rows = []
    priority = 1
    for p in profiles:
        manual = manual_review_links(p["query"])
        rows.append({
            "Priority": priority,
            "Vehicle year/model": f"{p.get('year')} Tesla {p.get('model')}",
            "Part type": p.get("part", ""),
            "Color": p.get("color", ""),
            "Query": p.get("query", ""),
            "eBay Motors URL": ebay_browser_url(p["query"]),
            "Craigslist priority URLs": "\n".join(craigslist_browser_url(site, p["query"]) for site in craigslist_sites),
            "Car-Part URL": manual["Car-Part.com"],
            "Copart URL": manual["Copart"],
            "IAAI URL": manual["IAAI"],
            "Facebook Marketplace manual URL": manual["Facebook Marketplace"],
        })
        priority += 1
    return rows


def build_pipeline_rows():
    return [
        {"Status": "New", "Meaning": "Fresh row from a monitored source or generated review link", "Manual action": "Open link and inspect details"},
        {"Status": "Strong Match", "Meaning": "Score is at/above alert threshold and direct listing data exists", "Manual action": "Review quickly and decide whether to contact seller"},
        {"Status": "Manual Review", "Meaning": "Sensitive/account source or source fetch unavailable; link is provided for safe manual check", "Manual action": "Open manually; no automated outreach"},
        {"Status": "Watchlist", "Meaning": "Possible match below alert threshold", "Manual action": "Keep or pass"},
        {"Status": "Contacted", "Meaning": "Rick manually contacted the seller", "Manual action": "Track response"},
        {"Status": "Waiting", "Meaning": "Waiting for seller/details", "Manual action": "Follow up manually"},
        {"Status": "Bought", "Meaning": "Part purchased", "Manual action": "Archive result"},
        {"Status": "Pass", "Meaning": "Not worth pursuing", "Manual action": "Leave notes"},
        {"Status": "Duplicate", "Meaning": "Same source/title/location/link already exists", "Manual action": "Suppress"},
    ]


def build_settings_rows(config):
    rules = config.get("safe_automation_rules", {})
    return [
        {"Setting": "Sheet name", "Value": config.get("sheet_name", "Tesla Parts Sniper V1 - Rick")},
        {"Setting": "Alert threshold", "Value": config.get("alert_threshold", 80)},
        {"Setting": "Alert email", "Value": config.get("alert_email", "")},
        {"Setting": "SMS", "Value": f"{config.get('alert_sms', '')} (provider not connected yet)"},
        {"Setting": "Automated outreach", "Value": "Disabled" if not rules.get("automated_outreach") else "Enabled"},
        {"Setting": "Facebook Marketplace", "Value": rules.get("facebook_marketplace", "manual/assisted review only")},
        {"Setting": "Copart / IAAI", "Value": rules.get("copart_iaai", "manual review first")},
        {"Setting": "Priority cities", "Value": ", ".join(config.get("priority_city_groups", []))},
        {"Setting": "Priority sources", "Value": ", ".join(config.get("sources_priority", []))},
    ]


def write_sheet_package(sheet_dir, config, profiles, craigslist_sites, listing_rows):
    sheet_dir = Path(sheet_dir)
    write_csv(sheet_dir / "01_Listings.csv", listing_rows, COLUMNS)
    write_csv(sheet_dir / "02_Search_Profiles.csv", build_search_profile_rows(config, profiles, craigslist_sites), SEARCH_PROFILE_COLUMNS)
    write_csv(sheet_dir / "03_Pipeline.csv", build_pipeline_rows(), PIPELINE_COLUMNS)
    write_csv(sheet_dir / "04_Settings.csv", build_settings_rows(config), SETTINGS_COLUMNS)
    return str(sheet_dir)
