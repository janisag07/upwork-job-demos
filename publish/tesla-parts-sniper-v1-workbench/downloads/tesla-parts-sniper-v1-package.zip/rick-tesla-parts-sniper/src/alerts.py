import os
import smtplib
from email.message import EmailMessage


def build_alert(row):
    return f"""Strong Tesla Part Match Found

{row['Vehicle year/model']} · {row['Part type']} · {row['Color'] or 'any color'}
Score: {row['Match score']}%
Source: {row['Source']}
Price: {row['Price'] or 'N/A'}
Location: {row['Location'] or 'N/A'}
Link: {row['Direct listing link']}

Status: {row['Status']}
Notes: {row['Notes']}

Manual review only. No automated seller outreach was performed.
"""


def send_email_alerts(rows):
    host = os.getenv("SMTP_HOST")
    user = os.getenv("SMTP_USER")
    password = os.getenv("SMTP_PASSWORD")
    to_addr = os.getenv("ALERT_TO")
    from_addr = os.getenv("ALERT_FROM") or user
    port = int(os.getenv("SMTP_PORT", "587"))
    if not all([host, user, password, to_addr, from_addr]):
        return {"sent": 0, "skipped": True, "reason": "SMTP env not configured"}
    sent = 0
    with smtplib.SMTP(host, port) as s:
        s.starttls()
        s.login(user, password)
        for row in rows:
            msg = EmailMessage()
            msg["Subject"] = f"Tesla Part Match {row['Match score']}%: {row['Part type']}"
            msg["From"] = from_addr
            msg["To"] = to_addr
            msg.set_content(build_alert(row))
            s.send_message(msg)
            sent += 1
    return {"sent": sent, "skipped": False}
