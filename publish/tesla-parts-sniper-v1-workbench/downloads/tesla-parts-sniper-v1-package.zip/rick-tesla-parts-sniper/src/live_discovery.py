import json
from pathlib import Path

from search_profiles import build_queries


def build_broad_live_profiles(config):
    """Broader fallback queries for actual marketplace hits.

    Exact year/color/part queries are good for precision but often have zero current listings.
    Rick explicitly asked to see real opportunities, so V1 also runs broader Tesla part queries
    against the same priority cities and scores the output honestly.
    """
    profiles = []
    seen = set()
    for vehicle in config["vehicles"][:2]:
        for part in ["hood", "front bumper", "rear bumper", "headlight", "door", "wheel"]:
            p = {
                "year": "",
                "model": vehicle["model"],
                "part": part,
                "color": "",
                "query": f"Tesla {vehicle['model']} {part}",
                "broad_live_discovery": True,
            }
            if p["query"] not in seen:
                seen.add(p["query"]); profiles.append(p)
    for q in ["Tesla parts", "Tesla Model Y parts", "Tesla Model 3 parts"]:
        if q not in seen:
            seen.add(q); profiles.append({"year":"", "model":"", "part":"parts", "color":"", "query":q, "broad_live_discovery": True})
    return profiles
