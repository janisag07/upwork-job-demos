import argparse
import json
from pathlib import Path

from dotenv import load_dotenv

from alerts import send_email_alerts
from exporters import to_sheet_row, write_csv, write_sheet_package
from live_discovery import build_broad_live_profiles
from search_profiles import build_queries
from sources import manual_source_rows, monitor_craigslist, monitor_ebay


def select_profiles(config, max_profiles=24):
    """Keep V1 practical, but do not drop Rick's configured parts.

    Earlier V1 capped the first few generated queries too aggressively, so later
    parts such as hatch/trunk/seat/suspension/module could be missing from the
    Google-Sheets package. This selector guarantees at least one base profile per
    configured part before filling remaining slots with color-specific priority
    variants.
    """
    queries = build_queries(config)
    configured_parts = list(dict.fromkeys(config.get("parts", [])))
    minimum = len(configured_parts)
    limit = max(int(max_profiles or 0), minimum)

    selected = []
    seen = set()

    # 1) Coverage pass: one non-color profile per part, preserving Rick's part order.
    for part in configured_parts:
        q = next((x for x in queries if x.get("part") == part and not x.get("color")), None)
        if q and q["query"] not in seen:
            selected.append(q)
            seen.add(q["query"])

    # 2) Priority fit pass: strongest colors/parts first, without losing coverage.
    priority_colors = ["white", "black", "red", "blue", "gray", ""]
    priority_parts = configured_parts
    for part in priority_parts:
        for color in priority_colors:
            if len(selected) >= limit:
                return selected
            q = next((x for x in queries if x.get("part") == part and x.get("color") == color), None)
            if q and q["query"] not in seen:
                selected.append(q)
                seen.add(q["query"])

    return selected[:limit]


def craigslist_sites(config):
    """Rick's latest priority: WA/OR, Bay Area, LA/SD, Idaho, Las Vegas first."""
    priority_sites = []
    fallback_sites = []
    for r in config["regions"]:
        target = priority_sites if r.get("priority") else fallback_sites
        target.extend(r.get("craigslist_sites", []))
    return priority_sites + fallback_sites


def run(config_path, output, max_per_query=3, include_manual=True, send_alerts=False, sheet_dir="output/google_sheet_import", max_profiles=10, max_sites=6):
    load_dotenv()
    config = json.loads(Path(config_path).read_text(encoding="utf-8"))
    profiles = select_profiles(config, max_profiles=max_profiles)
    sites = craigslist_sites(config)[:max_sites]
    raw = []
    for profile in profiles:
        raw.extend(monitor_ebay(profile, max_items=max_per_query))
        # Use priority sites, but cap max items per site. This gives Rick actual city coverage.
        raw.extend(monitor_craigslist(profile, sites, max_items=max_per_query))
        if include_manual:
            raw.extend(manual_source_rows(profile))
    # Broad live-discovery pass: exact year/color queries can be too narrow for current inventory.
    # This pass is what turns V1 into a real lead tool instead of only a search-link generator.
    for profile in build_broad_live_profiles(config)[:max_profiles]:
        raw.extend(monitor_ebay(profile, max_items=max_per_query))
        raw.extend(monitor_craigslist(profile, sites, max_items=max_per_query))
    seen = set()
    rows = [to_sheet_row(x, seen) for x in raw]
    rows.sort(key=lambda r: (r["Duplicate yes/no"] == "Yes", r["Status"] != "Strong Match", -int(r["Match score"] or 0), r["Source"]))
    write_csv(output, rows)
    sheet_package = write_sheet_package(sheet_dir, config, profiles, sites, rows)
    strong = [r for r in rows if r["Status"] == "Strong Match" and int(r["Match score"] or 0) >= int(config.get("alert_threshold", 80))]
    alert_result = {"sent": 0, "skipped": True, "reason": "not requested"}
    if send_alerts and strong:
        alert_result = send_email_alerts(strong[:10])
    return {
        "profiles": len(profiles),
        "rows": len(rows),
        "strong_matches": len(strong),
        "output": output,
        "sheet_import_dir": sheet_package,
        "alerts": alert_result,
        "safety": {
            "automated_outreach": False,
            "facebook_marketplace": "manual/assisted only",
            "copart_iaai": "manual review first",
        }
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/rick_v1.json")
    ap.add_argument("--output", default="output/listings.csv")
    ap.add_argument("--max-per-query", type=int, default=3)
    ap.add_argument("--no-manual", action="store_true")
    ap.add_argument("--send-alerts", action="store_true")
    ap.add_argument("--sheet-dir", default="output/google_sheet_import")
    ap.add_argument("--max-profiles", type=int, default=10)
    ap.add_argument("--max-sites", type=int, default=6)
    args = ap.parse_args()
    print(json.dumps(run(args.config, args.output, args.max_per_query, not args.no_manual, args.send_alerts, args.sheet_dir, args.max_profiles, args.max_sites), indent=2))


if __name__ == "__main__":
    main()
