import os
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from urllib.parse import quote_plus

import requests
from bs4 import BeautifulSoup

from search_profiles import ebay_url, ebay_browser_url, craigslist_rss_url, craigslist_browser_url, manual_review_links

HEADERS = {"User-Agent": "Mozilla/5.0 TeslaPartsSniperV1/1.0 (+manual-review; no-login-automation)"}
JINA_PREFIX = "https://r.jina.ai/http://r.jina.ai/http://"


def clean(text):
    return re.sub(r"\s+", " ", BeautifulSoup(text or "", "html.parser").get_text(" ")).strip()


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def fetch_xml(url, timeout=15):
    r = requests.get(url, headers=HEADERS, timeout=timeout)
    r.raise_for_status()
    return ET.fromstring(r.content)


def fetch_text(url, timeout=20):
    r = requests.get(url, headers=HEADERS, timeout=timeout)
    r.raise_for_status()
    return r.text


def jina_url(url):
    return JINA_PREFIX + url


def parse_rss(root, source, profile, region=""):
    rows = []
    for item in root.findall(".//item"):
        title = clean(item.findtext("title") or "")
        link = item.findtext("link") or ""
        desc = clean(item.findtext("description") or "")
        pub = item.findtext("pubDate") or item.findtext("date") or ""
        price = ""
        m = re.search(r"\$\s?[0-9][0-9,]*(?:\.\d{2})?", title + " " + desc)
        if m:
            price = m.group(0).replace(" ", "")
        rows.append({
            "source": source,
            "title": title,
            "price": price,
            "location": region,
            "description": desc[:500],
            "seller": "",
            "contact": "",
            "link": link,
            "date_found": now(),
            "published": pub,
            "profile": profile,
        })
    return rows


def _markdown_listing_blocks(markdown):
    pattern = re.compile(r"\[([^\]]{3,180})\]\((https?://[^)]+)\)")
    matches = list(pattern.finditer(markdown or ""))
    for i, m in enumerate(matches):
        title, link = clean(m.group(1)), m.group(2).strip()
        end = matches[i + 1].start() if i + 1 < len(matches) else min(len(markdown), m.end() + 700)
        context = markdown[m.end():end]
        yield title, link, context


def _price_from_context(context):
    m = re.search(r"\$\s?[0-9][0-9,]*(?:\.\d{2})?", context or "")
    return m.group(0).replace(" ", "") if m else ""


def _location_from_craigslist_context(context):
    # Craigslist Jina output usually shows: 4/27 rohnert pk / cotati \n\n $325
    lines = [clean(x) for x in (context or "").splitlines() if clean(x)]
    for line in lines[:6]:
        if re.match(r"\d{1,2}/\d{1,2}\s+", line):
            return re.sub(r"^\d{1,2}/\d{1,2}\s+", "", line).strip()
    for line in lines[:6]:
        if not line.startswith("$") and not line.startswith("[") and not line.startswith("•"):
            return line
    return ""


def _looks_relevant(title, profile):
    text = clean(title).lower()
    part = str(profile.get("part", "")).lower()
    model = str(profile.get("model", "")).lower()
    # Keep this permissive because marketplace titles are messy.
    return "tesla" in text and (part in text or model in text or "model" in text)


def parse_jina_craigslist_markdown(markdown, profile, site):
    rows = []
    seen = set()
    for title, link, context in _markdown_listing_blocks(markdown):
        if "/pts/" not in link and "/ptd/" not in link:
            continue
        if not link.endswith(".html"):
            continue
        if not _looks_relevant(title, profile):
            continue
        if link in seen:
            continue
        seen.add(link)
        location = _location_from_craigslist_context(context)
        rows.append({
            "source": "Craigslist",
            "title": title,
            "price": _price_from_context(context),
            "location": f"{site}" + (f" / {location}" if location else ""),
            "description": clean(context)[:500],
            "seller": "",
            "contact": "",
            "link": link,
            "date_found": now(),
            "profile": profile,
        })
    return rows


def parse_jina_ebay_markdown(markdown, profile):
    rows = []
    seen = set()
    for title, link, context in _markdown_listing_blocks(markdown):
        if "ebay.com/itm/" not in link:
            continue
        if not _looks_relevant(title, profile):
            continue
        if link in seen:
            continue
        seen.add(link)
        rows.append({
            "source": "eBay Motors",
            "title": title,
            "price": _price_from_context(context),
            "location": "Online / eBay",
            "description": clean(context)[:500],
            "seller": "",
            "contact": "",
            "link": link,
            "date_found": now(),
            "profile": profile,
        })
    return rows


def parse_ebay_finding_response(payload, profile):
    rows = []
    responses = payload.get("findItemsByKeywordsResponse", []) if isinstance(payload, dict) else []
    for response in responses:
        for result in response.get("searchResult", []):
            for item in result.get("item", []):
                title = (item.get("title") or [""])[0]
                link = (item.get("viewItemURL") or [""])[0]
                if not title or not link:
                    continue
                price = ""
                status = (item.get("sellingStatus") or [{}])[0]
                cur = (status.get("currentPrice") or [{}])[0]
                if cur.get("__value__"):
                    price = f"${float(cur['__value__']):.2f}"
                seller_info = (item.get("sellerInfo") or [{}])[0]
                rows.append({
                    "source": "eBay Motors",
                    "title": clean(title),
                    "price": price,
                    "location": (item.get("location") or ["Online / eBay"])[0],
                    "description": "Live eBay item from eBay Finding API.",
                    "seller": (seller_info.get("sellerUserName") or [""])[0],
                    "contact": "",
                    "link": link,
                    "date_found": now(),
                    "profile": profile,
                })
    return rows


def ebay_finding_api_url(query, app_id):
    q = quote_plus(query)
    return (
        "https://svcs.ebay.com/services/search/FindingService/v1?"
        "OPERATION-NAME=findItemsByKeywords&SERVICE-VERSION=1.0.0"
        f"&SECURITY-APPNAME={app_id}&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD"
        f"&keywords={q}&categoryId=6028&paginationInput.entriesPerPage=10"
    )


def monitor_ebay(profile, max_items=5):
    url = ebay_url(profile["query"])
    browser_url = ebay_browser_url(profile["query"])
    # 0) Official eBay Finding API if Janis/Rick provides an app id.
    app_id = os.getenv("EBAY_APP_ID") or os.getenv("EBAY_CLIENT_ID")
    if app_id:
        try:
            payload = requests.get(ebay_finding_api_url(profile["query"], app_id), headers=HEADERS, timeout=20).json()
            rows = parse_ebay_finding_response(payload, profile)[:max_items]
            if rows:
                return rows
        except Exception:
            pass
    # 1) Native RSS if eBay allows it.
    try:
        root = fetch_xml(url)
        rows = parse_rss(root, "eBay Motors", profile, "Online / eBay")[:max_items]
        if rows:
            return rows
    except Exception:
        pass
    # 2) Jina text extraction can work in some environments and gives real item links.
    try:
        md = fetch_text(jina_url(browser_url), timeout=25)
        rows = parse_jina_ebay_markdown(md, profile)[:max_items]
        if rows:
            return rows
        blocked = "blocked" in md.lower() or "security" in md.lower() or "451" in md[:200]
    except Exception as exc:
        blocked = True
        md = str(exc)
    return [{"source":"eBay Motors", "title":f"Live eBay pull blocked; direct review needed: {profile['query']}", "price":"", "location":"Online / eBay", "description":f"Automated eBay access unavailable from this environment ({md[:180]}). Direct search URL generated; not fake live inventory.", "seller":"", "contact":"", "link":browser_url, "date_found":now(), "profile":profile, "manual_only": True}]


def monitor_craigslist(profile, sites, max_items=5):
    out = []
    for site in sites:
        rss = craigslist_rss_url(site, profile["query"])
        browser = craigslist_browser_url(site, profile["query"])
        got = []
        try:
            root = fetch_xml(rss)
            got = parse_rss(root, "Craigslist", profile, site)[:max_items]
        except Exception:
            pass
        if not got:
            try:
                md = fetch_text(jina_url(browser), timeout=25)
                got = parse_jina_craigslist_markdown(md, profile, site)[:max_items]
            except Exception:
                got = []
        if got:
            out.extend(got)
        else:
            out.append({"source":"Craigslist", "title":f"No live Craigslist result found yet: {profile['query']} in {site}", "price":"", "location":site, "description":"Safe monitor checked this city/query and did not find a matching live listing in the parsed result set. Direct search URL included for review.", "seller":"", "contact":"", "link":browser, "date_found":now(), "profile":profile, "manual_only": True})
    return out


def build_car_part_usable_rows(profile):
    links = manual_review_links(profile["query"])
    return [{
        "source": "Car-Part.com",
        "title": f"Car-Part usable result workflow: {profile['query']}",
        "price": "",
        "location": "Nationwide / Car-Part",
        "description": "Car-Part blocks unauthenticated automated result extraction in this environment. V1 includes structured Car-Part search workflow and direct review link; not fake live inventory.",
        "seller": "",
        "contact": "",
        "link": links["Car-Part.com"],
        "date_found": now(),
        "profile": profile,
        "manual_only": True,
    }]


def manual_source_rows(profile):
    rows = []
    # Car-Part gets its own explicit row because Rick asked for usable results and we must be honest about access.
    rows.extend(build_car_part_usable_rows(profile))
    for source, link in manual_review_links(profile["query"]).items():
        if source == "Car-Part.com":
            continue
        rows.append({
            "source": source,
            "title": f"Manual review search: {profile['query']}",
            "price": "",
            "location": "West Coast",
            "description": "V1 manual/assisted source. Open link, review listing results, paste promising direct listings into the sheet. No automated outreach.",
            "seller": "",
            "contact": "",
            "link": link,
            "date_found": now(),
            "profile": profile,
            "manual_only": True,
        })
    return rows
