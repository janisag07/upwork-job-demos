"""Optional Google Sheets sync.

V1 default is CSV import because it is reliable without asking Rick/Janis for Google API credentials.
When credentials are available, this module can be extended to push rows directly through Google Sheets API.
"""

import csv


def preview_rows(csv_path, limit=10):
    with open(csv_path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))[:limit]
