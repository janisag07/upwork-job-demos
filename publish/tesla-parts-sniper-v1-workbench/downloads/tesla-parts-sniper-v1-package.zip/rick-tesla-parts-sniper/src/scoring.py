import re
from datetime import datetime, timezone

COLOR_ALIASES = {
    "gray": ["gray", "grey", "stealth gray", "midnight silver"],
    "white": ["white", "pearl white"],
    "black": ["black", "solid black"],
    "blue": ["blue", "deep blue"],
    "red": ["red", "ultra red", "multi-coat red"]
}


def norm(text):
    return re.sub(r"\s+", " ", (text or "").lower()).strip()


def contains_any(text, words):
    t = norm(text)
    return any(norm(w) in t for w in words if w)


def score_listing(listing, profile):
    title = norm(" ".join([listing.get("title", ""), listing.get("description", ""), listing.get("location", "")]))
    score = 0
    reasons = []

    if str(profile.get("year", "")) in title:
        score += 15; reasons.append("year match")
    if norm(profile.get("model", "")) in title:
        score += 20; reasons.append("model match")
    if norm(profile.get("part", "")) in title:
        score += 25; reasons.append("part match")

    color = norm(profile.get("color", ""))
    if color:
        aliases = COLOR_ALIASES.get(color, [color])
        if contains_any(title, aliases):
            score += 15; reasons.append("color match")
        else:
            score -= 5; reasons.append("color missing")

    if listing.get("price"):
        score += 5; reasons.append("price visible")
    if listing.get("link"):
        score += 5; reasons.append("direct link")

    source = listing.get("source", "")
    if source == "eBay Motors":
        score += 5; reasons.append("priority source")
    elif source == "Craigslist":
        score += 3; reasons.append("public source")
    elif source in {"Facebook Marketplace", "Car-Part.com", "Copart", "IAAI"}:
        score -= 2; reasons.append("manual review source")

    score = max(0, min(100, score))
    return score, ", ".join(reasons)


def duplicate_key(row):
    link = row.get("Direct listing link", "")
    if link and link.startswith("http"):
        raw = "|".join([row.get("Source", ""), link])
    else:
        raw = "|".join([row.get("Source", ""), row.get("Listing title", ""), row.get("Location", "")])
    return re.sub(r"[^a-z0-9]+", "-", raw.lower()).strip("-")


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
