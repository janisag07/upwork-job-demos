import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))

from sources import parse_jina_craigslist_markdown, parse_jina_ebay_markdown, build_car_part_usable_rows


PROFILE = {"year": 2024, "model": "Model Y", "part": "hood", "color": "white", "query": "Tesla 2024 Model Y hood white"}


def test_parse_jina_craigslist_markdown_extracts_actual_listing():
    md = """
Title: SF bay area auto parts for sale "Tesla Model Y hood" - craigslist

[2024 Tesla Model Y Hood White OEM](https://sfbay.craigslist.org/eby/pts/d/oakland-2024-tesla-model-hood/1234567890.html)
$450
Oakland, CA

[unrelated post](https://sfbay.craigslist.org/eby/pts/d/foo/999.html)
$20
"""
    rows = parse_jina_craigslist_markdown(md, PROFILE, "sfbay")
    assert rows
    row = rows[0]
    assert row["source"] == "Craigslist"
    assert "Tesla Model Y Hood" in row["title"]
    assert row["price"] == "$450"
    assert row["location"] == "sfbay / Oakland, CA"
    assert row["link"].startswith("https://sfbay.craigslist.org/")
    assert not row.get("manual_only")


def test_parse_jina_ebay_markdown_extracts_actual_listing():
    md = """
Title: Tesla 2024 Model Y hood white | eBay

[2024 TESLA MODEL Y FRONT HOOD PANEL WHITE OEM](https://www.ebay.com/itm/123456789012)
$899.00
Buy It Now

[Shop on eBay](https://www.ebay.com/) irrelevant
"""
    rows = parse_jina_ebay_markdown(md, PROFILE)
    assert rows
    row = rows[0]
    assert row["source"] == "eBay Motors"
    assert "TESLA MODEL Y" in row["title"]
    assert row["price"] == "$899.00"
    assert row["link"].startswith("https://www.ebay.com/itm/")
    assert not row.get("manual_only")


def test_car_part_usable_rows_are_not_fake_live_listings():
    rows = build_car_part_usable_rows(PROFILE)
    assert rows
    row = rows[0]
    assert row["source"] == "Car-Part.com"
    assert "usable result workflow" in row["title"].lower()
    assert row["manual_only"] is True
    assert "not fake live inventory" in row["description"].lower()
