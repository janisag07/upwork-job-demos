import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))

from sources import parse_ebay_finding_response

PROFILE = {"year": 2024, "model": "Model Y", "part": "hood", "color": "white", "query": "Tesla 2024 Model Y hood white"}


def test_parse_ebay_finding_response_extracts_live_items():
    payload = {
        "findItemsByKeywordsResponse": [{
            "searchResult": [{
                "item": [{
                    "title": ["2024 Tesla Model Y Hood White OEM"],
                    "viewItemURL": ["https://www.ebay.com/itm/123456789012"],
                    "sellingStatus": [{"currentPrice": [{"__value__": "899.00", "@currencyId": "USD"}]}],
                    "location": ["Los Angeles,CA,USA"],
                    "sellerInfo": [{"sellerUserName": ["teslapartsla"]}],
                }]
            }]
        }]
    }
    rows = parse_ebay_finding_response(payload, PROFILE)
    assert len(rows) == 1
    assert rows[0]["source"] == "eBay Motors"
    assert rows[0]["title"] == "2024 Tesla Model Y Hood White OEM"
    assert rows[0]["price"] == "$899.00"
    assert rows[0]["location"] == "Los Angeles,CA,USA"
    assert rows[0]["seller"] == "teslapartsla"
    assert rows[0]["link"] == "https://www.ebay.com/itm/123456789012"
    assert not rows[0].get("manual_only")
