import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))

from live_discovery import build_broad_live_profiles


def test_broad_live_profiles_include_realistic_queries():
    config = {"vehicles": [{"model": "Model Y"}, {"model": "Model 3"}]}
    profiles = build_broad_live_profiles(config)
    qs = [p["query"] for p in profiles]
    assert "Tesla Model Y hood" in qs
    assert "Tesla Model 3 front bumper" in qs
    assert "Tesla parts" in qs
    assert all(p["broad_live_discovery"] for p in profiles)
