# Tesla Parts Sniper V1

A safe V1 monitoring system for Rick Lycksell's Tesla parts workflow.

## Current Rick-approved scope

Rick confirmed on May 1:

- Janis should create the Google Sheet structure for V1 and share it with Rick.
- Alerts:
  - Email: configured in `config/rick_v1.json`
  - SMS number supplied, but SMS provider is not connected yet. Keep SMS pending until Twilio/Make/provider is confirmed.
- Rick does not have saved source URLs. Build from structured search logic.
- Copart and IAAI: Rick has accounts, but keep manual for now.
- Facebook Marketplace: manual/assisted only, no automation.
- Everything else: safe automation within limits.
- Priority cities/groups:
  - Washington / Oregon
  - Bay Area
  - Los Angeles / San Diego
  - Idaho
  - Las Vegas
- V1 must focus on real, usable part leads with direct links, clean scoring, and no duplicates.

## What this V1 does

- Builds Rick-specific Tesla part search profiles
- Runs an exact-query pass for Rick's requested year/model/part/color combinations
- Runs a broader live-discovery pass so real marketplace opportunities can appear even when exact year/color queries are too narrow
- Monitors low-risk public sources first where the network permits access:
  - eBay Motors via official Finding API when `EBAY_APP_ID`/`EBAY_CLIENT_ID` is provided, with RSS/browser fallback otherwise
  - Craigslist RSS/search pages by priority city, including Jina/text parsing fallback for live listings
- Creates manual-review links for sources that are risky or account-sensitive:
  - Car-Part.com
  - Copart
  - IAAI
  - Facebook Marketplace
- Scores each listing by vehicle, part, color, source, price visibility, and direct link
- Suppresses duplicates using normalized title/source/link/location keys
- Exports Google-Sheets-ready CSV tabs:
  1. `01_Listings.csv`
  2. `02_Search_Profiles.csv`
  3. `03_Pipeline.csv`
  4. `04_Settings.csv`
- Can send email alerts for strong matches when SMTP is configured
- Does **not** do automated seller outreach
- Does **not** automate Facebook login, messaging, posting, or aggressive scraping

## Rick's V1 scope

Priority sources:
1. eBay Motors
2. Car-Part.com
3. Craigslist
4. Copart / IAAI
5. Facebook Marketplace manual/assisted review first

Priority vehicles:
- 2024–2025 Model Y
- 2024–2025 Model 3
- 2021–2023 Model Y
- 2018–2023 Model 3

Priority parts:
- Hood
- Front bumper
- Rear bumper
- Fenders
- Headlights
- Doors
- Hatch / trunk
- Wheels
- Seats
- Suspension
- Modules

Priority colors:
- Red
- Black
- White
- Blue
- Gray

Output columns:
- Source
- Listing title
- Price
- Location
- Vehicle year/model
- Part type
- Color
- Seller name if available
- Phone/contact if available
- Direct listing link
- Date found
- Match score
- Duplicate yes/no
- Status
- Notes

## Quick start

```bash
cd /Users/nani/workspace/rick-tesla-parts-sniper
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python src/run_monitor.py \
  --config config/rick_v1.json \
  --output output/listings.csv \
  --sheet-dir output/google_sheet_import \
  --max-per-query 2
```

Then import these files into Google Sheets as separate tabs. The latest final run generated 148 sheet-ready rows and 3 unique real Craigslist listing links, plus source review rows for blocked/account-sensitive sources:

```text
output/google_sheet_import/01_Listings.csv
output/google_sheet_import/02_Search_Profiles.csv
output/google_sheet_import/03_Pipeline.csv
output/google_sheet_import/04_Settings.csv
```

## Google Sheets V1 workflow

Because Google Workspace API access is not authenticated in this environment yet, the current handoff-ready format is CSV tabs that can be imported into a Google Sheet immediately.

Recommended tabs:
1. `Listings` — live/exported opportunities and manual-review rows
2. `Search Profiles` — generated search terms and source URLs
3. `Pipeline` — manual statuses: New, Strong Match, Manual Review, Contacted, Waiting, Bought, Pass, Duplicate
4. `Settings` — source priorities, alert threshold, Rick's safety rules

If Google OAuth/API credentials become available, `src/google_sheets_sync.py` can be extended to push rows directly.

## Alert setup

Email alerts are optional. Configure `.env`:

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@email.com
SMTP_PASSWORD=***
ALERT_TO=ricklycksell@gmail.com
ALERT_FROM=your@email.com
```

Then run:

```bash
python src/run_monitor.py --config config/rick_v1.json --output output/listings.csv --send-alerts
```

SMS is intentionally not connected until Rick/Janis confirms the provider/method.

## Safety rules

- Facebook Marketplace stays manual/assisted in V1.
- No automated seller messaging.
- No login automation unless Rick explicitly provides accounts and accepts the risk.
- Craigslist/eBay are monitored with lightweight public access only.
- Car-Part/Copart/IAAI are included as generated search/review links first unless stable access is confirmed.
- If a source blocks automated HTTP access, the system outputs a direct browser/review URL instead of pretending it found a live listing.
