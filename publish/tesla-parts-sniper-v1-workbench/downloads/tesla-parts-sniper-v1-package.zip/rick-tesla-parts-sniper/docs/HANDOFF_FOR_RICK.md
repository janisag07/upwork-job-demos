# Tesla Parts Sniper V1 — Handoff Notes for Rick

Hi Rick,

V1 is now structured around your latest instructions:

- Google Sheets as the main dashboard/output
- eBay Motors and Craigslist as the first safe automated/public monitoring sources where access allows
- Car-Part, Copart, IAAI, and Facebook Marketplace as assisted/manual review links first
- Copart and IAAI stay manual because you have accounts and we are avoiding risky account automation in V1
- Facebook Marketplace stays manual/assisted only
- No automated outreach
- Priority city focus: Washington/Oregon, Bay Area, Los Angeles/San Diego, Idaho, and Las Vegas

## Sheet tabs

The import package contains four CSV tabs:

1. `Listings` — current matches/review links with scoring and duplicate flags
2. `Search Profiles` — generated search terms and direct source URLs
3. `Pipeline` — manual status workflow
4. `Settings` — alert/safety/source configuration

## Listing columns

The Listings tab uses exactly these fields:

1. Source
2. Listing title
3. Price
4. Location
5. Vehicle year/model
6. Part type
7. Color
8. Seller name if available
9. Phone/contact if available
10. Direct listing link
11. Date found
12. Match score
13. Duplicate yes/no
14. Status
15. Notes

## Status meanings

- `Strong Match`: score 80+ and good enough to review quickly
- `Manual Review`: sensitive/account source or public source currently requiring browser/manual review
- `Watchlist`: possible match below the alert threshold
- `Duplicate`: same title/source/link/location already seen

## V1 safety boundary

For Facebook Marketplace, I recommend manual/assisted review first. Automated browsing, scraping, or messaging can trigger account issues. V1 can save direct review links and organize promising listings, but it will not perform automated seller outreach.

For Copart and IAAI, V1 keeps account-based work manual first. The system generates structured search/review links, and you can open them while logged into your own accounts.

## Alerts

Email destination is set to your supplied email in the config. SMTP credentials still need to be connected before real email sending can run.

SMS is noted, but not activated yet because the provider/method still needs to be confirmed. I do not want to wire SMS through a provider without confirming the exact setup.

## Important note about live sources

The system tries safe public access first. Craigslist live parsing is working in the current environment and produced real listing links in the latest run. eBay and Car-Part may block automated access from this environment; when that happens, V1 outputs the direct search/review URL instead of pretending it found a live listing. That keeps the workflow reliable and avoids risky scraping.

## Next step for live deployment

Create/import the Google Sheet from the four CSV tabs in `output/google_sheet_import/`, then share it with Rick. Once SMTP/Google access is confirmed, the monitor can run on a schedule and keep the Sheet updated with real listings or direct review links.
