import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))

from exporters import build_search_profile_rows, build_settings_rows
from run_monitor import craigslist_sites
from scoring import duplicate_key, score_listing


def test_strong_match_scores_high():
    listing = {"source":"eBay Motors", "title":"2024 Tesla Model Y white front bumper OEM", "price":"$450", "link":"https://example.com"}
    profile = {"year":2024, "model":"Model Y", "part":"front bumper", "color":"white"}
    score, reasons = score_listing(listing, profile)
    assert score >= 80
    assert "part match" in reasons


def test_color_missing_penalty():
    listing = {"source":"Craigslist", "title":"2021 Tesla Model 3 rear bumper", "price":"$300", "link":"https://example.com"}
    profile = {"year":2021, "model":"Model 3", "part":"rear bumper", "color":"red"}
    score, reasons = score_listing(listing, profile)
    assert score < 85
    assert "color missing" in reasons


def test_duplicate_key_uses_direct_link_over_location():
    a = {"Source":"Craigslist", "Listing title":"Tesla Model 3 Parts", "Location":"seattle / Marysville", "Direct listing link":"https://seattle.craigslist.org/see/pts/d/marysville-tesla-model-3-parts/7921311562.html"}
    b = {"Source":"Craigslist", "Listing title":"Tesla Model Y 3 Parts", "Location":"spokane / Marysville", "Direct listing link":"https://seattle.craigslist.org/see/pts/d/marysville-tesla-model-3-parts/7921311562.html"}
    assert duplicate_key(a) == duplicate_key(b)


def test_rick_priority_cities_are_first():
    config = {"regions": [
        {"state": "Washington", "priority": True, "craigslist_sites": ["seattle"]},
        {"state": "Arizona", "priority": False, "craigslist_sites": ["phoenix"]},
        {"state": "California", "priority": True, "craigslist_sites": ["sfbay", "losangeles", "sandiego"]},
    ]}
    assert craigslist_sites(config)[:4] == ["seattle", "sfbay", "losangeles", "sandiego"]
    assert craigslist_sites(config)[-1] == "phoenix"


def test_google_sheet_profile_export_contains_direct_urls():
    config = {}
    profiles = [{"year": 2024, "model": "Model Y", "part": "hood", "color": "white", "query": "Tesla 2024 Model Y hood white"}]
    rows = build_search_profile_rows(config, profiles, ["sfbay", "losangeles"])
    row = rows[0]
    assert "ebay.com" in row["eBay Motors URL"]
    assert "sfbay.craigslist.org" in row["Craigslist priority URLs"]
    assert "facebook.com/marketplace" in row["Facebook Marketplace manual URL"]


def test_settings_include_alert_email_and_safety():
    rows = build_settings_rows({
        "sheet_name": "Tesla Parts Sniper V1 - Rick",
        "alert_email": "ricklycksell@gmail.com",
        "alert_sms": "3609750369",
        "priority_city_groups": ["Washington / Oregon", "Bay Area"],
        "sources_priority": ["eBay Motors", "Car-Part.com"],
        "safe_automation_rules": {"automated_outreach": False, "facebook_marketplace": "manual only"}
    })
    values = {r["Setting"]: str(r["Value"]) for r in rows}
    assert values["Alert email"] == "ricklycksell@gmail.com"
    assert values["Automated outreach"] == "Disabled"
    assert "Bay Area" in values["Priority cities"]
